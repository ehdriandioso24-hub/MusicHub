package com.musichub.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import android.util.Base64
import kotlinx.coroutines.delay
import java.net.URLEncoder

private val Background = Color(0xFF090611)
private val SurfaceDark = Color(0xFF171323)
private val Accent = Color(0xFF9B35FF)
private val Muted = Color(0xFFBDB5CE)

private data class Track(val id: String, val title: String)
private enum class HubTab(val label: String) { HOME("Home"), FAVORITES("Favorites"), PLAYLIST("Playlist"), RECENT("Recent") }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Background, surface = SurfaceDark, primary = Accent,
                onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
            )) {
                var showSplash by remember { mutableStateOf(true) }
                LaunchedEffect(Unit) { delay(1200); showSplash = false }
                if (showSplash) SplashArtwork() else MusicHubScreen()
            }
        }
    }
}

@Composable
private fun SplashArtwork() {
    androidx.compose.foundation.Image(
        painter = androidx.compose.ui.res.painterResource(id = R.drawable.musichub_splash),
        contentDescription = "MusicHub loading screen",
        modifier = Modifier.fillMaxSize()
    )
}

private fun encodeTrack(track: Track): String {
    val title = Base64.encodeToString(track.title.toByteArray(Charsets.UTF_8), Base64.NO_WRAP or Base64.URL_SAFE)
    return "${track.id}|$title"
}

private fun decodeTracks(values: Set<String>): List<Track> = values.mapNotNull { value ->
    val parts = value.split('|', limit = 2)
    if (parts.size != 2 || !parts[0].matches(Regex("[A-Za-z0-9_-]{6,20}"))) null
    else try { Track(parts[0], String(Base64.decode(parts[1], Base64.NO_WRAP or Base64.URL_SAFE), Charsets.UTF_8)) } catch (_: Exception) { null }
}

private fun extractYouTubeId(raw: String): String? {
    return try {
        val uri = Uri.parse(raw.trim())
        val host = (uri.host ?: "").lowercase()
        val id = when {
            host == "youtu.be" -> uri.lastPathSegment
            host.endsWith("youtube.com") || host.endsWith("youtube-nocookie.com") -> when {
                uri.path == "/watch" -> uri.getQueryParameter("v")
                uri.pathSegments.firstOrNull()?.let { it in listOf("embed", "shorts", "live") } == true -> uri.pathSegments.getOrNull(1)
                else -> null
            }
            else -> null
        }
        id?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{11}")) }
    } catch (_: Exception) { null }
}

@Composable
private fun MusicHubScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("musichub_v120", 0) }
    var searchQuery by remember { mutableStateOf("") }
    var videoLink by remember { mutableStateOf("") }
    var titleInput by remember { mutableStateOf("") }
    var currentTrack by remember { mutableStateOf<Track?>(null) }
    var selectedTab by remember { mutableStateOf(HubTab.HOME) }
    var favorites by remember { mutableStateOf(decodeTracks(prefs.getStringSet("favorites", emptySet()) ?: emptySet())) }
    var playlist by remember { mutableStateOf(decodeTracks(prefs.getStringSet("playlist", emptySet()) ?: emptySet())) }
    var recent by remember { mutableStateOf(decodeTracks(prefs.getStringSet("recent", emptySet()) ?: emptySet())) }

    fun persist(key: String, tracks: List<Track>) {
        prefs.edit().putStringSet(key, tracks.map { encodeTrack(it) }.toSet()).apply()
    }
    fun notify(message: String) = Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    fun openTrack(track: Track) {
        currentTrack = track
        recent = (listOf(track) + recent.filterNot { it.id == track.id }).take(30)
        persist("recent", recent)
        selectedTab = HubTab.HOME
    }
    fun addFromLink() {
        val id = extractYouTubeId(videoLink)
        if (id == null) { notify("Hindi valid na YouTube video link. Subukan ang youtube.com/watch?v=..."); return }
        val track = Track(id, titleInput.trim().ifBlank { "YouTube video" })
        openTrack(track)
        videoLink = ""
        titleInput = ""
    }
    fun searchYouTube() {
        val term = searchQuery.trim()
        if (term.isEmpty()) { notify("Maglagay muna ng song o artist."); return }
        val encoded = URLEncoder.encode(term, "UTF-8")
        try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded"))) }
        catch (_: Exception) { notify("Hindi mabuksan ang YouTube.") }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Background) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("♫", color = Accent, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Column(Modifier.padding(start = 10.dp)) {
                    Text("MusicHub", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Your music space", color = Muted, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                HubTab.values().forEach { tab ->
                    FilterChip(selected = selectedTab == tab, onClick = { selectedTab = tab }, label = { Text(tab.label, fontSize = 11.sp) })
                }
            }
            when (selectedTab) {
                HubTab.HOME -> {
                    Text("Play YouTube in MusicHub", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp))
                    Text("Maghanap sa YouTube, pagkatapos kopyahin ang video link at ilagay rito.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp, bottom = 10.dp))
                    OutlinedTextField(value = searchQuery, onValueChange = { searchQuery = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                        placeholder = { Text("Search song or artist…", color = Muted) }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { searchYouTube() }))
                    Button(onClick = { searchYouTube() }, modifier = Modifier.fillMaxWidth().padding(top = 7.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("Search on YouTube") }
                    OutlinedTextField(value = titleInput, onValueChange = { titleInput = it }, modifier = Modifier.fillMaxWidth().padding(top = 12.dp), singleLine = true, placeholder = { Text("Video title (optional)", color = Muted) })
                    OutlinedTextField(value = videoLink, onValueChange = { videoLink = it }, modifier = Modifier.fillMaxWidth().padding(top = 7.dp), singleLine = true, placeholder = { Text("Paste YouTube video link…", color = Muted) })
                    Button(onClick = { addFromLink() }, modifier = Modifier.fillMaxWidth().padding(top = 7.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("Play in MusicHub") }
                    currentTrack?.let { track ->
                        Spacer(Modifier.height(14.dp))
                        Text("NOW PLAYING", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        Text(track.title, color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(vertical = 5.dp))
                        YouTubePlayer(track.id, Modifier.fillMaxWidth().height(220.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = {
                                favorites = if (favorites.any { it.id == track.id }) favorites.filterNot { it.id == track.id } else listOf(track) + favorites
                                persist("favorites", favorites)
                                notify(if (favorites.any { it.id == track.id }) "Na-save sa Favorites." else "Inalis sa Favorites.")
                            }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark)) {
                                Text(if (favorites.any { it.id == track.id }) "♥ Favorited" else "♡ Favorite")
                            }
                            Button(onClick = {
                                if (playlist.none { it.id == track.id }) { playlist = listOf(track) + playlist; persist("playlist", playlist); notify("Naidagdag sa Playlist.") }
                                else notify("Nasa Playlist na ito.")
                            }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark)) { Text("＋ Playlist") }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("QUICK SEARCH", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    listOf("OPM hits", "Chill music", "Acoustic songs", "Workout music").forEach { item ->
                        Card(Modifier.fillMaxWidth().padding(top = 6.dp).clickable { searchQuery = item; val encoded = URLEncoder.encode(item, "UTF-8"); context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded"))) }, colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
                            Text(item, Modifier.padding(13.dp), color = Color.White)
                        }
                    }
                }
                HubTab.FAVORITES -> TrackList("FAVORITES", favorites, onSelect = { openTrack(it) }, onRemove = { favorites = favorites.filterNot { item -> item.id == it.id }; persist("favorites", favorites) }, modifier = Modifier.weight(1f))
                HubTab.PLAYLIST -> TrackList("MY PLAYLIST", playlist, onSelect = { openTrack(it) }, onRemove = { playlist = playlist.filterNot { item -> item.id == it.id }; persist("playlist", playlist) }, modifier = Modifier.weight(1f))
                HubTab.RECENT -> TrackList("RECENTLY PLAYED", recent, onSelect = { openTrack(it) }, onRemove = { recent = recent.filterNot { item -> item.id == it.id }; persist("recent", recent) }, modifier = Modifier.weight(1f))
            }
            Spacer(Modifier.height(6.dp))
            Text("YouTube playback follows YouTube's player rules. Background playback while the screen is locked is not guaranteed.", color = Muted, fontSize = 10.sp, lineHeight = 13.sp)
        }
    }
}

@Composable
private fun TrackList(title: String, tracks: List<Track>, onSelect: (Track) -> Unit, onRemove: (Track) -> Unit, modifier: Modifier = Modifier) {
    Text(title, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 10.dp))
    if (tracks.isEmpty()) Text("Wala pang laman. Magpatugtog muna ng video para makapagdagdag dito.", color = Muted, fontSize = 13.sp)
    else LazyColumn(modifier.fillMaxWidth()) {
        items(tracks, key = { it.id }) { track ->
            Card(Modifier.fillMaxWidth().padding(bottom = 7.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(12.dp)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).clickable { onSelect(track) }) {
                        Text(track.title, color = Color.White, fontWeight = FontWeight.Medium)
                        Text("YouTube video", color = Muted, fontSize = 10.sp)
                    }
                    Text("▶", color = Accent, modifier = Modifier.clickable { onSelect(track) }.padding(8.dp))
                    Text("✕", color = Muted, modifier = Modifier.clickable { onRemove(track) }.padding(8.dp))
                }
            }
        }
    }
}

@Composable
private fun YouTubePlayer(videoId: String, modifier: Modifier = Modifier) {
    AndroidView(modifier = modifier, factory = { ctx ->
        WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = true
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            setBackgroundColor(android.graphics.Color.BLACK)
        }
    }, update = { webView ->
        val html = """
            <!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"></head>
            <body style="margin:0;background:#000"><div id="player"></div>
            <script>
              var tag=document.createElement('script'); tag.src='https://www.youtube.com/iframe_api';
              document.head.appendChild(tag);
              function onYouTubeIframeAPIReady(){new YT.Player('player',{width:'100%',height:'220',videoId:'$videoId',playerVars:{playsinline:1,rel:0},events:{}});}
            </script></body></html>
        """.trimIndent()
        if (webView.tag != videoId) {
            webView.tag = videoId
            webView.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "UTF-8", null)
        }
    })
}
