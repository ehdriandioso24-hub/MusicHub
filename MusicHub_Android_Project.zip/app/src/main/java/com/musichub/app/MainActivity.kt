package com.musichub.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.res.painterResource
import kotlinx.coroutines.delay
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.net.URLEncoder

private val Background = Color(0xFF090611)
private val SurfaceDark = Color(0xFF171323)
private val Accent = Color(0xFF9B35FF)
private val Muted = Color(0xFFBDB5CE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    background = Background,
                    surface = SurfaceDark,
                    primary = Accent,
                    onPrimary = Color.White,
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                var showSplash by remember { mutableStateOf(true) }
                LaunchedEffect(Unit) {
                    delay(1400)
                    showSplash = false
                }
                if (showSplash) SplashArtwork() else MusicHubScreen()
            }
        }
    }
}

@Composable
private fun SplashArtwork() {
    Image(
        painter = painterResource(id = R.drawable.musichub_splash),
        contentDescription = "MusicHub loading screen",
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
private fun MusicHubScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("musichub", 0) }
    var query by remember { mutableStateOf("") }
    var savedSearches by remember {
        mutableStateOf<List<String>>(
            (prefs.getStringSet("saved_searches", emptySet<String>()) ?: emptySet<String>())
                .toList().sorted()
        )
    }

    fun searchYouTube(term: String) {
        val clean = term.trim()
        if (clean.isEmpty()) {
            Toast.makeText(context, "Maglagay muna ng song o artist.", Toast.LENGTH_SHORT).show()
            return
        }
        val encoded = URLEncoder.encode(clean, "UTF-8")
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded"))
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
            Toast.makeText(context, "Walang app o browser na makapagbubukas ng YouTube.", Toast.LENGTH_LONG).show()
        }
    }

    fun toggleSaved(term: String) {
        val updated = savedSearches.toMutableSet()
        if (updated.contains(term)) updated.remove(term) else updated.add(term)
        savedSearches = updated.toList().sorted()
        prefs.edit().putStringSet("saved_searches", updated.toSet()).apply()
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Background) {
        Column(
            modifier = Modifier.fillMaxSize().background(Background)
                .padding(horizontal = 20.dp, vertical = 22.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("♫", color = Accent, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Column(Modifier.padding(start = 10.dp)) {
                    Text("MusicHub", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Discover music you love", color = Muted, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(26.dp))
            Text("Find your next favorite", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text(
                "Search songs, artists, and music videos on YouTube.",
                color = Muted, fontSize = 14.sp,
                modifier = Modifier.padding(top = 5.dp, bottom = 16.dp)
            )
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(16.dp),
                placeholder = { Text("Search song or artist…", color = Muted) },
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = { searchYouTube(query) })
            )
            Button(
                onClick = { searchYouTube(query) },
                modifier = Modifier.fillMaxWidth().padding(top = 12.dp).height(50.dp),
                shape = RoundedCornerShape(15.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Accent)
            ) { Text("Search on YouTube", fontWeight = FontWeight.Bold) }

            Spacer(Modifier.height(24.dp))
            Text("QUICK SEARCH", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            listOf("OPM hits", "Chill music", "Acoustic songs", "Workout music").forEach { item ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp).clickable { searchYouTube(item) },
                    colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(item, color = Color.White, fontWeight = FontWeight.Medium)
                        Text("↗", color = Accent, fontSize = 20.sp)
                    }
                }
            }
            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("SAVED SEARCHES", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Tap ☆ to remove", color = Muted, fontSize = 10.sp)
            }
            if (savedSearches.isEmpty()) {
                Text("Wala pang saved searches. Maghanap at i-save ang paborito mong search.", color = Muted, fontSize = 12.sp)
            } else {
                LazyColumn(modifier = Modifier.weight(1f, fill = false)) {
                    items(items = savedSearches, key = { it }) { savedItem ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(savedItem, modifier = Modifier.weight(1f).clickable { searchYouTube(savedItem) }, color = Color.White)
                            Text("☆", modifier = Modifier.size(36.dp).clickable { toggleSaved(savedItem) }, color = Accent, fontSize = 22.sp)
                        }
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
            Text(
                "YouTube playback opens through the official YouTube app or website. Background playback depends on YouTube's own account and service rules.",
                color = Muted, fontSize = 10.sp, lineHeight = 14.sp
            )
        }
    }
}
