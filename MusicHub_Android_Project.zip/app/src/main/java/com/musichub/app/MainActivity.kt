package com.musichub.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.LibraryMusic
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import android.util.Base64
import kotlinx.coroutines.delay
import java.net.URLEncoder

private val Background = Color(0xFF101113)
private val SurfaceDark = Color(0xFF202125)
private val SurfaceRaised = Color(0xFF292A2F)
private val Accent = Color(0xFFC18A52)
private val AccentSoft = Color(0xFFD8B18A)
private val Muted = Color(0xFFB8B0A7)

private data class Track(val id: String, val title: String)
private enum class HubTab(val label: String) { HOME("Home"), SEARCH("Search"), FAVORITES("Favorites"), LIBRARY("Library") }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Background, surface = SurfaceDark, primary = Accent, secondary = AccentSoft,
                onPrimary = Color.White, onBackground = Color.White, onSurface = Color.White
            )) {
                var showSplash by remember { mutableStateOf(true) }
                LaunchedEffect(Unit) { delay(1200); showSplash = false }
                if (showSplash) SplashArtwork() else MusicHubScreen()
            }
        }
    }
}

@Composable
private fun SplashArtwork() {
    androidx.compose.foundation.Image(
        painter = androidx.compose.ui.res.painterResource(id = R.drawable.musichub_splash),
        contentDescription = "MusicHub loading screen",
        modifier = Modifier.fillMaxSize()
    )
}

private fun encodeTrack(track: Track): String {
    val title = Base64.encodeToString(track.title.toByteArray(Charsets.UTF_8), Base64.NO_WRAP or Base64.URL_SAFE)
    return "${track.id}|$title"
}

private fun decodeTracks(values: Set<String>): List<Track> = values.mapNotNull { value ->
    val parts = value.split('|', limit = 2)
    if (parts.size != 2 || !parts[0].matches(Regex("[A-Za-z0-9_-]{6,20}"))) null
    else try { Track(parts[0], String(Base64.decode(parts[1], Base64.NO_WRAP or Base64.URL_SAFE), Charsets.UTF_8)) } catch (_: Exception) { null }
}

private fun extractYouTubeId(raw: String): String? {
    return try {
        val uri = Uri.parse(raw.trim())
        val host = (uri.host ?: "").lowercase()
        val id = when {
            host == "youtu.be" -> uri.lastPathSegment
            host.endsWith("youtube.com") || host.endsWith("youtube-nocookie.com") -> when {
                uri.path == "/watch" -> uri.getQueryParameter("v")
                uri.pathSegments.firstOrNull()?.let { it in listOf("embed", "shorts", "live") } == true -> uri.pathSegments.getOrNull(1)
                else -> null
            }
            else -> null
        }
        id?.takeIf { it.matches(Regex("[A-Za-z0-9_-]{11}")) }
    } catch (_: Exception) { null }
}

@Composable
private fun MusicHubScreen() {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("musichub_v120", 0) }
    var searchQuery by remember { mutableStateOf("") }
    var videoLink by remember { mutableStateOf("") }
    var titleInput by remember { mutableStateOf("") }
    var currentTrack by remember { mutableStateOf<Track?>(null) }
    var selectedTab by remember { mutableStateOf(HubTab.HOME) }
    var showNowPlaying by remember { mutableStateOf(false) }
    var showCreatePlaylist by remember { mutableStateOf(false) }
    var newPlaylistName by remember { mutableStateOf("") }
    var showAddToPlaylist by remember { mutableStateOf(false) }
    var selectedLibraryPlaylist by remember { mutableStateOf<String?>(null) }
    var favorites by remember { mutableStateOf(decodeTracks(prefs.getStringSet("favorites", emptySet()) ?: emptySet())) }
    var recent by remember { mutableStateOf(decodeTracks(prefs.getStringSet("recent", emptySet()) ?: emptySet())) }
    var playlistNames by remember { mutableStateOf((prefs.getStringSet("playlist_names", setOf("My Playlist")) ?: setOf("My Playlist")).toList().sorted()) }
    var playlists by remember {
        mutableStateOf<Map<String, List<Track>>>(
            playlistNames.associateWith { name ->
                val stored = prefs.getStringSet(playlistKey(name), null)
                if (stored != null) decodeTracks(stored)
                else if (name == "My Playlist") decodeTracks(prefs.getStringSet("playlist", emptySet()) ?: emptySet())
                else emptyList<Track>()
            }
        )
    }
    fun notify(message: String) = Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
    val audioPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) { }
            val playIntent = Intent(context, MusicPlaybackService::class.java).apply {
                action = MusicPlaybackService.ACTION_PLAY_URI
                putExtra(MusicPlaybackService.EXTRA_URI, uri.toString())
            }
            try {
                ContextCompat.startForegroundService(context, playIntent)
                notify("Playing local audio in background.")
            } catch (_: Exception) {
                notify("Hindi masimulan ang background player.")
            }
        }
    }

    fun persistTracks(key: String, tracks: List<Track>) {
        prefs.edit().putStringSet(key, tracks.map { encodeTrack(it) }.toSet()).apply()
    }
    fun persistPlaylist(name: String, tracks: List<Track>) {
        playlists = playlists + (name to tracks)
        persistTracks(playlistKey(name), tracks)
    }
    fun openTrack(track: Track) {
        currentTrack = track
        recent = (listOf(track) + recent.filterNot { it.id == track.id }).take(30)
        persistTracks("recent", recent)
        showNowPlaying = true
    }
    fun searchYouTube() {
        val term = searchQuery.trim()
        if (term.isEmpty()) { notify("Maglagay muna ng song o artist."); return }
        val encoded = URLEncoder.encode(term, "UTF-8")
        try { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded"))) }
        catch (_: Exception) { notify("Hindi mabuksan ang YouTube.") }
    }
    fun addFromLink() {
        val id = extractYouTubeId(videoLink)
        if (id == null) { notify("Hindi valid ang YouTube video link."); return }
        openTrack(Track(id, titleInput.trim().ifBlank { "YouTube video" }))
        videoLink = ""
        titleInput = ""
    }
    fun toggleFavorite(track: Track) {
        favorites = if (favorites.any { it.id == track.id }) favorites.filterNot { it.id == track.id } else listOf(track) + favorites
        persistTracks("favorites", favorites)
    }

    if (showCreatePlaylist) {
        AlertDialog(
            onDismissRequest = { showCreatePlaylist = false },
            title = { Text("Create playlist") },
            text = { OutlinedTextField(value = newPlaylistName, onValueChange = { newPlaylistName = it }, singleLine = true, label = { Text("Playlist name") }) },
            confirmButton = { TextButton(onClick = {
                val name = newPlaylistName.trim()
                if (name.isNotEmpty() && playlistNames.none { it.equals(name, true) }) {
                    playlistNames = (playlistNames + name).sorted()
                    prefs.edit().putStringSet("playlist_names", playlistNames.toSet()).apply()
                    persistPlaylist(name, emptyList())
                    selectedLibraryPlaylist = name
                    newPlaylistName = ""
                    showCreatePlaylist = false
                } else notify("Maglagay ng bagong pangalan ng playlist.")
            }) { Text("Create") } },
            dismissButton = { TextButton(onClick = { showCreatePlaylist = false }) { Text("Cancel") } }
        )
    }

    if (showAddToPlaylist) {
        AlertDialog(
            onDismissRequest = { showAddToPlaylist = false },
            title = { Text("Add to playlist") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    playlistNames.forEach { name ->
                        TextButton(onClick = {
                            val track = currentTrack
                            if (track != null) {
                                val updated = listOf(track) + (playlists[name] ?: emptyList()).filterNot { it.id == track.id }
                                persistPlaylist(name, updated)
                                notify("Naidagdag sa $name.")
                            }
                            showAddToPlaylist = false
                        }, modifier = Modifier.fillMaxWidth()) { Text(name, modifier = Modifier.fillMaxWidth()) }
                    }
                    TextButton(onClick = { showAddToPlaylist = false; showCreatePlaylist = true }) { Text("＋ Create new playlist") }
                }
            },
            confirmButton = { TextButton(onClick = { showAddToPlaylist = false }) { Text("Close") } }
        )
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Background) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("♫", color = Accent, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                Column(Modifier.padding(start = 10.dp)) {
                    Text("MusicHub", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Color.White)
                    Text("Your music space", color = Muted, fontSize = 12.sp)
                }
                Spacer(Modifier.weight(1f))
                currentTrack?.let {
                    Text("▶", color = Accent, fontSize = 20.sp, modifier = Modifier.clickable { showNowPlaying = true }.padding(8.dp))
                }
            }
            if (showNowPlaying && currentTrack != null) {
                NowPlayingScreen(
                    track = currentTrack!!,
                    isFavorite = favorites.any { it.id == currentTrack!!.id },
                    onBack = { showNowPlaying = false },
                    onFavorite = { toggleFavorite(currentTrack!!) },
                    onAddPlaylist = { showAddToPlaylist = true }
                )
            } else {
                Box(Modifier.weight(1f).fillMaxWidth()) {
                    when (selectedTab) {
                        HubTab.HOME -> HomeScreen(
                            currentTrack = currentTrack,
                            searchQuery = searchQuery,
                            onSearchChange = { searchQuery = it },
                            onSearch = { selectedTab = HubTab.SEARCH; searchYouTube() },
                            titleInput = titleInput,
                            onTitleChange = { titleInput = it },
                            videoLink = videoLink,
                            onLinkChange = { videoLink = it },
                            onPlayLink = { addFromLink() },
                            recent = recent,
                            onSelectTrack = { openTrack(it) },
                            onOpenSearch = { selectedTab = HubTab.SEARCH },
                            onPickAudio = { audioPicker.launch(arrayOf("audio/*")) }
                        )
                        HubTab.SEARCH -> SearchScreen(
                            query = searchQuery,
                            onQueryChange = { searchQuery = it },
                            onSearch = { searchYouTube() },
                            titleInput = titleInput,
                            onTitleChange = { titleInput = it },
                            videoLink = videoLink,
                            onLinkChange = { videoLink = it },
                            onPlayLink = { addFromLink() }
                        )
                        HubTab.FAVORITES -> TrackList("FAVORITES", favorites, { openTrack(it) }, { track -> favorites = favorites.filterNot { it.id == track.id }; persistTracks("favorites", favorites) })
                        HubTab.LIBRARY -> LibraryScreen(
                            names = playlistNames,
                            playlists = playlists,
                            recent = recent,
                            selectedPlaylist = selectedLibraryPlaylist,
                            onSelectPlaylist = { selectedLibraryPlaylist = it },
                            onCreatePlaylist = { showCreatePlaylist = true },
                            onPlay = { openTrack(it) },
                            onRemove = { name, track -> persistPlaylist(name, (playlists[name] ?: emptyList()).filterNot { it.id == track.id }) },
                            onRemoveRecent = { track -> recent = recent.filterNot { it.id == track.id }; persistTracks("recent", recent) }
                        )
                    }
                }
                NavigationBar(containerColor = SurfaceDark, contentColor = Color.White) {
                    NavigationBarItem(selected = selectedTab == HubTab.HOME, onClick = { selectedTab = HubTab.HOME }, icon = { Icon(Icons.Filled.Home, null) }, label = { Text("Home") })
                    NavigationBarItem(selected = selectedTab == HubTab.SEARCH, onClick = { selectedTab = HubTab.SEARCH }, icon = { Icon(Icons.Filled.Search, null) }, label = { Text("Search") })
                    NavigationBarItem(selected = selectedTab == HubTab.FAVORITES, onClick = { selectedTab = HubTab.FAVORITES }, icon = { Icon(Icons.Filled.Favorite, null) }, label = { Text("Favorites") })
                    NavigationBarItem(selected = selectedTab == HubTab.LIBRARY, onClick = { selectedTab = HubTab.LIBRARY }, icon = { Icon(Icons.Filled.LibraryMusic, null) }, label = { Text("Library") })
                }
            }
        }
    }
}

private fun playlistKey(name: String): String = "playlist_" + Base64.encodeToString(name.toByteArray(Charsets.UTF_8), Base64.NO_WRAP or Base64.URL_SAFE)

@Composable
private fun HomeScreen(
    currentTrack: Track?, searchQuery: String, onSearchChange: (String) -> Unit, onSearch: () -> Unit,
    titleInput: String, onTitleChange: (String) -> Unit, videoLink: String, onLinkChange: (String) -> Unit,
    onPlayLink: () -> Unit, recent: List<Track>, onSelectTrack: (Track) -> Unit, onOpenSearch: () -> Unit,
    onPickAudio: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp).padding(bottom = 12.dp)) {
        Text("WELCOME TO YOUR SOUNDSPACE", color = AccentSoft, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.6.sp, modifier = Modifier.padding(top = 8.dp))
        Text("Music, with character.", fontSize = 25.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 5.dp))
        Text("Your personal listening room.", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 3.dp, bottom = 14.dp))
        Card(Modifier.fillMaxWidth().clickable { onOpenSearch() }, colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Search, null, tint = Accent)
                Text("Search songs and artists on YouTube", color = Muted, modifier = Modifier.padding(start = 10.dp))
            }
        }
        Text("PLAY A YOUTUBE VIDEO", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp, bottom = 7.dp))
        OutlinedTextField(value = titleInput, onValueChange = onTitleChange, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Video title (optional)") })
        OutlinedTextField(value = videoLink, onValueChange = onLinkChange, modifier = Modifier.fillMaxWidth().padding(top = 7.dp), singleLine = true, label = { Text("Paste YouTube video link") })
        Button(onClick = onPlayLink, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("Play in MusicHub") }
        Card(
            modifier = Modifier.fillMaxWidth().padding(top = 12.dp).clickable { onPickAudio() },
            colors = CardDefaults.cardColors(containerColor = SurfaceRaised),
            shape = RoundedCornerShape(16.dp)
        ) {
            Row(Modifier.fillMaxWidth().background(Brush.linearGradient(listOf(Color(0xFF34302B), SurfaceRaised))).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("♫", color = AccentSoft, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                Column(Modifier.weight(1f).padding(start = 12.dp)) {
                    Text("Play local audio in background", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("Choose an audio file • Lock-screen controls", color = Muted, fontSize = 11.sp)
                }
                Text("›", color = AccentSoft, fontSize = 26.sp)
            }
        }
        if (currentTrack != null) {
            Text("NOW PLAYING", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp))
            Text(currentTrack.title, color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 5.dp))
            Text("Tap the player icon above or open Now Playing from the track list.", color = Muted, fontSize = 11.sp)
        }
        if (recent.isNotEmpty()) {
            Text("RECENTLY PLAYED", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
            LazyColumn(Modifier.weight(1f, fill = false)) {
                items(recent.take(5), key = { it.id }) { track ->
                    Card(Modifier.fillMaxWidth().padding(bottom = 6.dp).clickable { onSelectTrack(track) }, colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("▶", color = Accent)
                            Text(track.title, color = Color.White, modifier = Modifier.padding(start = 10.dp))
                        }
                    }
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Text("YouTube playback follows its official player rules. Background audio is available for selected local audio files.", color = Muted, fontSize = 10.sp, lineHeight = 13.sp)
    }
}

@Composable
private fun SearchScreen(
    query: String, onQueryChange: (String) -> Unit, onSearch: () -> Unit,
    titleInput: String, onTitleChange: (String) -> Unit, videoLink: String, onLinkChange: (String) -> Unit, onPlayLink: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Search music", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Search opens official YouTube results. Paste a video link below to play it here.", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp, bottom = 12.dp))
        OutlinedTextField(value = query, onValueChange = onQueryChange, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Song title or artist") }, keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions(onSearch = { onSearch() }))
        Button(onClick = onSearch, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("Search on YouTube") }
        Text("QUICK SEARCH", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 18.dp, bottom = 6.dp))
        listOf("OPM hits", "Chill music", "Acoustic songs", "Workout music", "Instrumental study music").forEach { item ->
            Card(Modifier.fillMaxWidth().padding(bottom = 6.dp).clickable { onQueryChange(item); onSearch() }, colors = CardDefaults.cardColors(containerColor = SurfaceDark)) { Text(item, Modifier.padding(13.dp), color = Color.White) }
        }
        Spacer(Modifier.height(12.dp))
        Text("PLAY BY VIDEO LINK", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(value = titleInput, onValueChange = onTitleChange, modifier = Modifier.fillMaxWidth().padding(top = 6.dp), singleLine = true, label = { Text("Video title (optional)") })
        OutlinedTextField(value = videoLink, onValueChange = onLinkChange, modifier = Modifier.fillMaxWidth().padding(top = 6.dp), singleLine = true, label = { Text("YouTube video link") })
        Button(onClick = onPlayLink, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("Play in MusicHub") }
    }
}

@Composable
private fun NowPlayingScreen(track: Track, isFavorite: Boolean, onBack: () -> Unit, onFavorite: () -> Unit, onAddPlaylist: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("‹  Back", color = Accent, fontSize = 16.sp, modifier = Modifier.clickable { onBack() }.padding(vertical = 8.dp))
            Spacer(Modifier.weight(1f))
            Text("NOW PLAYING", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().weight(1f, fill = false).aspectRatio(1f).background(Brush.linearGradient(listOf(Color(0xFF3B3027), Color(0xFF242326), Color(0xFF17181B))), RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("M U S I C H U B", color = AccentSoft, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                Text("♫", color = Accent, fontSize = 100.sp, fontWeight = FontWeight.Bold)
                Text("OBSIDIAN  •  BRONZE EDITION", color = Muted, fontSize = 9.sp, letterSpacing = 1.5.sp)
            }
        }
        Text(track.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 16.dp))
        Text("YouTube video", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp, bottom = 10.dp))
        YouTubePlayer(track.id, Modifier.fillMaxWidth().height(230.dp))
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = onFavorite, modifier = Modifier.weight(1f)) { Text(if (isFavorite) "♥ Saved" else "♡ Favorite") }
            Button(onClick = onAddPlaylist, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("＋ Playlist") }
        }
        Text("Use the controls in the embedded YouTube player for playback.", color = Muted, fontSize = 10.sp, modifier = Modifier.padding(top = 10.dp, bottom = 8.dp))
    }
}

@Composable
private fun TrackList(title: String, tracks: List<Track>, onSelect: (Track) -> Unit, onRemove: (Track) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(vertical = 12.dp))
        if (tracks.isEmpty()) Text("Wala pang laman. Magpatugtog muna ng video para makapagdagdag dito.", color = Muted, fontSize = 13.sp)
        else LazyColumn(Modifier.fillMaxSize()) {
            items(tracks, key = { it.id }) { track ->
                Card(Modifier.fillMaxWidth().padding(bottom = 7.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(12.dp)) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f).clickable { onSelect(track) }) {
                            Text(track.title, color = Color.White, fontWeight = FontWeight.Medium)
                            Text("YouTube video", color = Muted, fontSize = 10.sp)
                        }
                        Text("▶", color = Accent, modifier = Modifier.clickable { onSelect(track) }.padding(8.dp))
                        Text("✕", color = Muted, modifier = Modifier.clickable { onRemove(track) }.padding(8.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun LibraryScreen(
    names: List<String>, playlists: Map<String, List<Track>>, recent: List<Track>, selectedPlaylist: String?,
    onSelectPlaylist: (String?) -> Unit, onCreatePlaylist: () -> Unit, onPlay: (Track) -> Unit,
    onRemove: (String, Track) -> Unit, onRemoveRecent: (Track) -> Unit
) {
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Your Library", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Button(onClick = onCreatePlaylist, colors = ButtonDefaults.buttonColors(containerColor = Accent)) { Text("＋ New") }
        }
        if (selectedPlaylist == null) {
            Text("PLAYLISTS", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 7.dp))
            names.forEach { name ->
                Card(Modifier.fillMaxWidth().padding(bottom = 7.dp).clickable { onSelectPlaylist(name) }, colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.LibraryMusic, null, tint = Accent)
                        Column(Modifier.padding(start = 10.dp).weight(1f)) {
                            Text(name, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("${playlists[name]?.size ?: 0} tracks", color = Muted, fontSize = 11.sp)
                        }
                        Text("›", color = Muted, fontSize = 24.sp)
                    }
                }
            }
            Text("RECENTLY PLAYED", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
            if (recent.isEmpty()) Text("Wala pang recently played.", color = Muted, fontSize = 12.sp)
            else LazyColumn(Modifier.weight(1f)) {
                items(recent, key = { it.id }) { track ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(track.title, color = Color.White, modifier = Modifier.weight(1f).clickable { onPlay(track) })
                        Text("▶", color = Accent, modifier = Modifier.clickable { onPlay(track) }.padding(8.dp))
                        Text("✕", color = Muted, modifier = Modifier.clickable { onRemoveRecent(track) }.padding(8.dp))
                    }
                }
            }
        } else {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("‹  All playlists", color = Accent, modifier = Modifier.clickable { onSelectPlaylist(null) }.padding(vertical = 8.dp))
            }
            Text(selectedPlaylist, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp))
            val tracks = playlists[selectedPlaylist] ?: emptyList()
            if (tracks.isEmpty()) Text("Walang kanta sa playlist na ito. Magpatugtog ng video at piliin ang + Playlist.", color = Muted, fontSize = 13.sp)
            else LazyColumn(Modifier.fillMaxSize()) {
                items(tracks, key = { it.id }) { track ->
                    Card(Modifier.fillMaxWidth().padding(bottom = 7.dp), colors = CardDefaults.cardColors(containerColor = SurfaceDark)) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f).clickable { onPlay(track) }) { Text(track.title, color = Color.White); Text("YouTube video", color = Muted, fontSize = 10.sp) }
                            Text("▶", color = Accent, modifier = Modifier.clickable { onPlay(track) }.padding(8.dp))
                            Text("✕", color = Muted, modifier = Modifier.clickable { onRemove(selectedPlaylist, track) }.padding(8.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun YouTubePlayer(videoId: String, modifier: Modifier = Modifier) {
    AndroidView(modifier = modifier, factory = { ctx ->
        WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = true
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            setBackgroundColor(android.graphics.Color.BLACK)
        }
    }, update = { webView ->
        val html = """
            <!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1"></head>
            <body style="margin:0;background:#000"><div id="player"></div>
            <script>
              var tag=document.createElement('script'); tag.src='https://www.youtube.com/iframe_api';
              document.head.appendChild(tag);
              function onYouTubeIframeAPIReady(){new YT.Player('player',{width:'100%',height:'230',videoId:'$videoId',playerVars:{playsinline:1,rel:0},events:{}});}
            </script></body></html>
        """.trimIndent()
        if (webView.tag != videoId) {
            webView.tag = videoId
            webView.loadDataWithBaseURL("https://www.youtube.com", html, "text/html", "UTF-8", null)
        }
    })
}
