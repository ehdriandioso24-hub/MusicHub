# MusicHub v1.2.0

Dark Android music app starter with neon-purple launcher icon and custom loading artwork.

## Features
- Official YouTube embedded player for supported video links.
- Search handoff to the official YouTube app or website (no YouTube Data API key required for this link-based workflow).
- Local Favorites, one personal Playlist, and Recently Played lists.
- Existing dark design, launcher icon, and splash artwork retained.

## Notes
- To search and display YouTube results directly inside the app, a YouTube Data API integration can be added later.
- Playback uses the official YouTube embedded player. Background playback while the device is locked is not guaranteed and is not bypassed.
- This project does not download or extract YouTube audio.

## Build
GitHub Actions builds the debug APK using Java 17 and Gradle 8.9. Run the `Build MusicHub Android APK` workflow manually or push a change to the project.
