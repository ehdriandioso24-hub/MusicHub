# MusicHub Android starter

A dark-themed Android music discovery starter app.

## What this starter does
- Search YouTube by song or artist.
- Opens search results using the official YouTube app or website.
- Saves and removes favorite search terms locally on the device.
- Builds a debug APK with GitHub Actions.

## Important YouTube playback limitation
This starter does not extract YouTube audio, bypass ads, or provide unauthorized background playback. YouTube playback is handed off to the official YouTube app or website. Whether YouTube continues playing with the screen off depends on YouTube's own service, account eligibility, and settings.

For background playback inside MusicHub, add a separate player only for audio streams that you own, license, or are explicitly authorized to stream. Use Android Media3 for that separate feature.

## Build locally
1. Open this folder in Android Studio.
2. Allow Gradle sync.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).

The project uses Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, and compile SDK 35.

## Build with GitHub
1. Create a GitHub repository named `MusicHub`.
2. Upload the contents of this folder to the repository root (not the ZIP file itself).
3. Open Actions.
4. Select `Build MusicHub Android APK`.
5. Click `Run workflow`.
6. Download `MusicHub-debug-apk` from the completed workflow run's Artifacts section.
