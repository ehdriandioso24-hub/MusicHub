# MusicHub v1.3.0 — Obsidian Bronze & Background Audio

## What's new
- Premium Obsidian Bronze visual theme: charcoal surfaces, bronze accents, layered cards, and a custom Now Playing artwork panel.
- Local audio file picker from the Home screen.
- AndroidX Media3 `MediaSessionService` for background playback of user-selected local audio files.
- Media-session notification and lock-screen controls are provided by Android/Media3.
- Existing YouTube embedded playback remains in-app and continues to follow YouTube's official player rules. This update does **not** enable or promise YouTube background playback and does not extract YouTube audio.
- Existing Favorites, Playlists, Recently Played, app icon, splash screen, and GitHub Actions workflow are retained.

## Background audio
On Home, tap **Play local audio in background** and select an audio file available on the device. Playback runs through Android Media3 in a media playback foreground service. The media notification/lock-screen controls are managed by the Android media session.

Only use audio files you own or are authorized to play. YouTube videos continue to play using the official embedded player while MusicHub is open; background playback for YouTube is not guaranteed.

## Build
GitHub Actions runs `gradle --no-daemon assembleDebug` and uploads `app/build/outputs/apk/debug/app-debug.apk` as `MusicHub-v1.3.0-debug-apk`.

Build verification must be completed by running the GitHub Actions workflow after uploading this project.
