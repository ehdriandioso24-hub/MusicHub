# MusicHub Android starter
Dark-themed Android music discovery app.

- Search YouTube by song or artist through the official YouTube app or website.
- Quick search suggestions.
- Save and remove search terms locally.

This app does not extract YouTube audio, bypass advertisements, or override YouTube background-playback restrictions. Background playback depends on YouTube's own service and account rules.

Build uses Java 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Kotlin 2.0.21, and compile SDK 35.
