# MusicHub v1.1.0
Dark MusicHub Android starter with neon-purple launcher icon and custom loading screen.

- Launcher icon assets are included for mdpi through xxxhdpi.
- AndroidX Core SplashScreen 1.0.1 provides the native launch splash.
- A custom MusicHub loading artwork displays briefly before the Home screen.
- YouTube search opens the official YouTube app or website.
- This app does not extract YouTube audio or bypass background-playback restrictions.

Build: Java 17, Gradle 8.9, AGP 8.7.3, Kotlin 2.0.21, compile SDK 35.
